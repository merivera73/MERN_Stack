import { createContext } from 'react';
import NameForm from './NameForm';

const MyContext = createContext();

export default MyContext;